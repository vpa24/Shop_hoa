<?php
include("controllers/c_hoa_don.php");
$c_hoa_don = new C_hoa_don();
$c_hoa_don->ChiTiet();
?>
