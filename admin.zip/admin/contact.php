<?php
include("controllers/c_contact.php");
$c_contact = new C_contact();
$c_contact->show_contact();
?>