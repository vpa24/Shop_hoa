<?php
if(isset($_COOKIE['permission'])){
    if($_COOKIE['permission'] != 1){
        header('Location: index.php');
        exit;
    }
}
?>