<?php
include("controllers/c_dang_nhap.php");
$c_dang_nhap = new C_dang_nhap();
$c_dang_nhap->hien_thi_trang_dang_nhap();
?>