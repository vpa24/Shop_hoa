<?php
include("controllers/c_dang_xuat.php");
$c_dang_xuat = new C_dang_xuat();
$c_dang_xuat->trang_dang_xuat();
?>