<?php
include("controllers/c_doi_mat_khau.php");
$c_doi_mat_khau = new C_doi_mat_khau();
$c_doi_mat_khau->trang_doi_mat_khau();
?>