<?php
include("controllers/c_hien_thi_thong_bao_don_hang.php");
$c_hien_thi_thong_bao_don_hang = new C_hien_thi_thong_bao_don_hang();
$c_hien_thi_thong_bao_don_hang->hien_thi();
?>