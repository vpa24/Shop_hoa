<?php
include("controllers/c_hoa.php");
$c_hoa = new C_hoa();
$c_hoa->hien_thi_hoa();
?>