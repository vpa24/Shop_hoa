<?php
include("controllers/c_index.php");
$c_index = new C_index();
$c_index->hien_thi_trang_index();
?>