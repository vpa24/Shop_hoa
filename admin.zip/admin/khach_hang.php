<?php
include("controllers/c_khach_hang.php");
$c_khach_hang = new C_khach_hang();
$c_khach_hang->hien_thi_khach_hang();
?>