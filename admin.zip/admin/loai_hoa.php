<?php
include("controllers/c_loai_hoa.php");
$c_loai_hoa = new C_loai_hoa();
$c_loai_hoa->hien_thi_loai_hoa();
?>