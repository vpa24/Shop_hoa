<?php
include("controllers/c_logo.php");
$c_logo = new C_logo();
$c_logo->hien_thi_logo();
?>
